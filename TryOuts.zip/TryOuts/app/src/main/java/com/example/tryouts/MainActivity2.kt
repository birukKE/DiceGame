package com.example.tryouts
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


// Det här är en annan aktivitet för den andra sidan som kommer upp när spelaren har kastat klart
class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val restart_button:Button = findViewById(R.id.restart)
        // Vi går tillbaka till spelet om spelaren trycker på restart knappen
        restart_button.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // Vi tar emot data som skickade av MainActivity
        val point = getIntent().getIntExtra("game_point", 0)

        val point_wrt:TextView = findViewById(R.id.pointTxt)

        var result = getIntent().getStringExtra("result")

        result = "You got " + point + " "  + "points\n" + "These were the choices you made at each round:\n" + result

        point_wrt.text = result



    }
}