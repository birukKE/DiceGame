package com.example.tryouts
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

// Den här klass är huvudklassen, det är här i princip allt kombineras för att få en fungerande app.
class MainActivity : AppCompatActivity() {
    var isBtnClicked = false
    var gameRoundCount = 0
    val MAX_NUMBER_OF_ROUNDS = 10
    var list_of_btns = mutableListOf<Button>()
    var list_for_rounds: ArrayList<ArrayList<Int>> = ArrayList(MAX_NUMBER_OF_ROUNDS)
    val imageViewModel: ImageHandle by viewModels()
    var saveTextForDiceList = " "
    val scoreManage = ScoreManager()
    lateinit var myText: TextView
    lateinit var listDice: TextView
    lateinit var spinnerID: Spinner
    lateinit var btn: Button
    var listDice_text = "      Roll the dice!"



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialiserar listorna inuti arraylistan där tärningarnas värde för varje omgång kommer att sparas
        for (ii in 1..MAX_NUMBER_OF_ROUNDS+1) {
            list_for_rounds.add(ArrayList())
        }

        // Initialiserar alla objekt(knappar, imageview, spinner osv) som jag behöver använda
        btn = findViewById(R.id.mButton)
        spinnerID = findViewById<Spinner>(R.id.spinId)
        listDice = findViewById<TextView>(R.id.diceText)
        myText = findViewById<TextView>(R.id.txtId)
        myText.text = scoreManage.saveTextFormyText
        listDice.text = listDice_text

        // Skapar variabler av de olika objekten nedan
        val imgView1 = findViewById<ImageView>(R.id.imageView1)
        val imgView2 = findViewById<ImageView>(R.id.imageView2)
        val imgView3 = findViewById<ImageView>(R.id.imageView3)
        val imgView4 = findViewById<ImageView>(R.id.imageView4)
        val imgView5 = findViewById<ImageView>(R.id.imageView5)
        val imgView6 = findViewById<ImageView>(R.id.imageView6)

        val btn1: Button = findViewById(R.id.pickBtn1)
        val btn2: Button = findViewById(R.id.pickBtn2)
        val btn3: Button = findViewById(R.id.pickBtn3)
        val btn4: Button = findViewById(R.id.pickBtn4)
        val btn5: Button = findViewById(R.id.pickBtn5)
        val btn6: Button = findViewById(R.id.pickBtn6)

        // Lägger variablerna i listor för att det ska bli lättare att iterera över dem senare
        val imgViewList = arrayOf(imgView1, imgView2, imgView3, imgView4, imgView5, imgView6)
        val curImgVisibilityList = arrayOf(imageViewModel.curImgVisibility1, imageViewModel.curImgVisibility2, imageViewModel.curImgVisibility3, imageViewModel.curImgVisibility4, imageViewModel.curImgVisibility5, imageViewModel.curImgVisibility6)
        val btnStatusList = arrayOf(imageViewModel.btnEnabled1, imageViewModel.btnEnabled2, imageViewModel.btnEnabled3, imageViewModel.btnEnabled4, imageViewModel.btnEnabled5, imageViewModel.btnEnabled6)
        val listOfDrawables = arrayOf(imageViewModel.curImg1, imageViewModel.curImg2, imageViewModel.curImg3, imageViewModel.curImg4, imageViewModel.curImg5, imageViewModel.curImg6)

        list_of_btns.add(btn1)
        list_of_btns.add(btn2)
        list_of_btns.add(btn3)
        list_of_btns.add(btn4)
        list_of_btns.add(btn5)
        list_of_btns.add(btn6)

        spinnerID.isEnabled = scoreManage.saveSpinnerState


        // Main button listner
        btn.setOnClickListener {
            isBtnClicked = true

            // Vi byter aktivitet när villkoret innuti denna funktion är fyllt och då byter vi också aktivitet
            changeActivity()

            //Ändra texten för knappen (button) givet villkor
            if(scoreManage.btnText.equals("Next\nRound") && gameRoundCount < MAX_NUMBER_OF_ROUNDS) {
                scoreManage.btnText = "Roll Dice"
                btn.text = scoreManage.btnText
            }

            // hasSelectedMenu kommer sättas tills false vid tredje omgången så om btn är tryckt
            // och sedan kalla på funktionen dropDwonMenu och låta spelaren välja
            // poängs alternativ men det sker endast vid tredje omgången och sedan kommer den sättas till true
            if (scoreManage.gameEntryCount == 3 && scoreManage.hasSelectedMenu == false) {
                scoreManage.dropDownMenu(this, myText, spinnerID, list_for_rounds, gameRoundCount, btn)
            }

            // Om man inte valt samma alternativ och om man inte har valt något alternativ än så får man gå vidare med spelet
            if (scoreManage.hasPickedSameMenu == false && scoreManage.hasSelectedMenu == true) {

                // gameEntryCount räknar antalet gånger vi kan slå per runda och vi ska slå 3 gånger
                // så har vi inte nått gränset så updaterar vi skärmen och fortsätter slänga tärningar som ej är valda.
                if (scoreManage.gameEntryCount < 3 && gameRoundCount < MAX_NUMBER_OF_ROUNDS) {
                    // Uppdatera imageview med slupmässigt tärning sidor
                    imageViewModel.img_update()

                    //Ändra texten för knappen (button) givet villkor
                    scoreManage.btnText = "Roll Dice"
                    btn.text = scoreManage.btnText
                    if(scoreManage.gameEntryCount == 2) scoreManage.btnText = "Confirm"
                    btn.text = scoreManage.btnText
                }

                // Varje 3 gånger så kommer användaren välja dropDownMenu vilket siffra de vill ha och
                // jag skriver även ut vilka tärningar de har fått och ökar gameRoundCounter och kör om spelet.
                if (scoreManage.gameEntryCount == 3 && gameRoundCount < MAX_NUMBER_OF_ROUNDS) {
                    //Ändra texten för knappen (button) givet villkor
                    if(!scoreManage.btnText.equals("Next\nRound") && !scoreManage.btnText.equals("Roll Dice")) {
                        scoreManage.btnText = "Activate\nmenu"
                        btn.text = scoreManage.btnText}

                     // Ge instruktioner till användaren
                    scoreManage.saveTextFormyText = "     Must activate menu then you must select from it! "
                    myText.text = scoreManage.saveTextFormyText

                    // Ta hand om uppdatering av villkor och bilder efter varje tredje omgång
                    scoreManage.hasSelectedMenu = false
                    addRemainingDiceVal()
                    imageViewModel.reset_images()
                    for (i in 0..5) {
                        imgViewList[i].visibility = View.VISIBLE
                        var index = i+1
                        var curName = "curImgVisibility"+index
                        var btnName = "btnEnabled"+index
                        imageViewModel.setValue(curName, true)
                        imageViewModel.setValue(btnName, true)
                        list_of_btns[i].isEnabled = true

                    }
                    // Visa användaren tärningsresultatet
                    listDice_text = "     Your chosen dice this round: " + list_for_rounds[gameRoundCount].joinToString(", ")
                    listDice.text = listDice_text

                    // Det här är viktigaste villkoret av alla, det är här då användaren faktiskt har valt ett godkänt val och vi ökar viktiga counters
                    // samt uppdaterar viktiga flaggor
                    if(!scoreManage.selectedChoice.equals(" ") && !scoreManage.menuChoiceStorage.contains(scoreManage.selectedChoice)){
                        scoreManage.menuChoiceStorage.add(scoreManage.selectedChoice.toString())
                        listDice_text = "      Roll the dice!"
                        listDice.text = listDice_text
                        scoreManage.saveTextFormyText = ""
                        myText.text = scoreManage.saveTextFormyText

                        gameRoundCount++
                        scoreManage.gameEntryCount = -1
                        scoreManage.hasSelectedMenu = true
                    }

                }
                scoreManage.gameEntryCount++
                if(scoreManage.gameEntryCount>3){ scoreManage.gameEntryCount = 3 }
            }
        }
        // Här lyssnar vi på de andra 6 buttons som tillhör de olika tärningarna och när man klickar på dessa
        // så är detsamma som att man plockar upp de och de försvinner och knappen stängs av.
        btn1.setOnClickListener {
            whenBtnClicken(imgView1, btn1, "curImgVisibility1", "btnEnabled1")
        }
        btn2.setOnClickListener {
            whenBtnClicken(imgView2, btn2, "curImgVisibility2", "btnEnabled2")
        }
        btn3.setOnClickListener {
            whenBtnClicken(imgView3, btn3, "curImgVisibility3", "btnEnabled3")
        }
        btn4.setOnClickListener {
            whenBtnClicken(imgView4, btn4, "curImgVisibility4", "btnEnabled4")
        }
        btn5.setOnClickListener {
            whenBtnClicken(imgView5, btn5, "curImgVisibility5", "btnEnabled5")
        }
        btn6.setOnClickListener {
            whenBtnClicken(imgView6, btn6, "curImgVisibility6", "btnEnabled6")

        }

        // Den här for-loopen är för att se till att status av objekten (btn, imgview och flaggor) sparas mha ViewModel
        // när man t.ex. roterar mobilen (dvs när aktiviten dör).
        for (i in 0..5) {
            curImgVisibilityList[i].observe(this) { isVisible ->
                if (isVisible == false) {
                    imgViewList[i].visibility = View.INVISIBLE
                } else {
                    imgViewList[i].visibility = View.VISIBLE
                }
            }
            btnStatusList[i].observe(this) { isEnabled ->
                if (isEnabled == false) {
                    list_of_btns[i].isEnabled = false
                }
            }
            listOfDrawables[i].observe(this) { drawable_id ->
                imgViewList[i].setImageResource(drawable_id)
                imgViewList[i].tag = drawable_id
            }
        }

    }

    // Denna funktion beskriver vad som sker när man trycker på knapparna gjorda för tärningarna dvs knapparna för att behålla en tärning.
    fun whenBtnClicken(imgView: ImageView, btn: Button, curImgName:String, btnEnableName:String){
        // Vi måste garantera att "Main" knappen är tryckt och att det nuvarande drawable inte är "dice0"
        // för då är det dags att välja poäng alternativ
        if ((imgView.drawable.constantState != ContextCompat.getDrawable(this, R.drawable.dice0)?.constantState) && isBtnClicked == true) {
            imgView.visibility = View.INVISIBLE
            btn.isEnabled = false
            imageViewModel.setValue(curImgName, false)
            imageViewModel.setValue(btnEnableName, false)
            imageViewModel.save_diceVal(this, imgView, list_for_rounds, gameRoundCount)
            //myText.text = "List is: " + list_for_rounds[0].joinToString(",")
        }
    }

    // Denna funktion använder save_diceval funktion som sparar tärningarna i en lista som användaren väljer att behålla
    // och vid tredje gången behöver vi inte välja då  det kommer att automatisk räknas in. Dessutom avaktiverar den knapparna.
    fun addRemainingDiceVal() {
        for (i in 0..list_of_btns.size - 1) {
            if (list_of_btns[i].isEnabled) {
                when (i) {
                    0 -> {imageViewModel.save_diceVal(this, findViewById<ImageView>(R.id.imageView1), list_for_rounds, gameRoundCount)
                        imageViewModel.setValue("btnEnabled1", false)
                    }
                    1 -> {imageViewModel.save_diceVal(this, findViewById<ImageView>(R.id.imageView2), list_for_rounds, gameRoundCount)
                        imageViewModel.setValue("btnEnabled2", false)
                    }
                    2 -> {imageViewModel.save_diceVal(this, findViewById<ImageView>(R.id.imageView3), list_for_rounds, gameRoundCount)

                        imageViewModel.setValue("btnEnabled3", false)
                    }
                    3 -> {imageViewModel.save_diceVal(this, findViewById<ImageView>(R.id.imageView4), list_for_rounds, gameRoundCount)

                        imageViewModel.setValue("btnEnabled4", false)
                    }
                    4 -> {imageViewModel.save_diceVal(this, findViewById<ImageView>(R.id.imageView5), list_for_rounds, gameRoundCount)

                        imageViewModel.setValue("btnEnabled5", false)
                    }
                    5 -> {imageViewModel.save_diceVal(this, findViewById<ImageView>(R.id.imageView6), list_for_rounds, gameRoundCount)

                        imageViewModel.setValue("btnEnabled6", false)
                    }
                }
            }
        }
    }

    // Det här funktion för att byta skräm/ sida när en viss villkor inuti den uppfylls
    // dvs innan 11:e omgången startas
    fun changeActivity(){
        if (gameRoundCount == MAX_NUMBER_OF_ROUNDS) {
            val intent = Intent(this, MainActivity2::class.java)
            var point_sum = 0
            for (elem in scoreManage.pointSumList) {
                point_sum += elem
            }
            intent.putExtra("game_point", point_sum)

            var result = ""
            for (i in 0..list_for_rounds.size - 2) {
                //                        result += innerList.joinToString(", ")
                result += "Selected choice " + scoreManage.menuChoiceStorage[i] + " for round " + list_for_rounds[i].joinToString(", ")
                result += "\n"
            }
            intent.putExtra("result", result)
            startActivity(intent)
            finish()
        }
    }

    // funktion för att spara viktiga värden
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putSerializable("savedList", list_for_rounds)
        outState.putInt("save_gameEntryCount", scoreManage.gameEntryCount)
        outState.putInt("save_gameRoundCount", gameRoundCount)
        outState.putBoolean("BtnClicked", isBtnClicked)
        outState.putSerializable("menuChoiceStorage", scoreManage.menuChoiceStorage)
        outState.putBoolean("hasPickedSameMenu", scoreManage.hasPickedSameMenu)
        outState.putBoolean("hasSelectedMenu", scoreManage.hasSelectedMenu)
        outState.putBoolean("saveSpinnerState", scoreManage.saveSpinnerState)
        outState.putString("saveTextFormyText", scoreManage.saveTextFormyText)
        outState.putString("listDice_text", listDice_text)
        outState.putSerializable("pointSumList", scoreManage.pointSumList)
        outState.putString("selectedChoice", scoreManage.selectedChoice)
        outState.putString("btnText", scoreManage.btnText)

    }



    // funktion för att återställa de viktiga värden
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        var saveList = savedInstanceState.getSerializable("savedList")
        if (saveList != null) {
            list_for_rounds = saveList as ArrayList<ArrayList<Int>>
        }
        scoreManage.gameEntryCount = savedInstanceState.getInt("save_gameEntryCount")
        gameRoundCount = savedInstanceState.getInt("save_gameRoundCount")
        isBtnClicked = savedInstanceState.getBoolean("BtnClicked")
        scoreManage.menuChoiceStorage = savedInstanceState.getSerializable("menuChoiceStorage") as ArrayList<String>
        scoreManage.hasPickedSameMenu = savedInstanceState.getBoolean("hasPickedSameMenu")
        scoreManage.hasSelectedMenu = savedInstanceState.getBoolean("hasSelectedMenu")
        scoreManage.saveSpinnerState = savedInstanceState.getBoolean("saveSpinnerState")
        spinnerID.isEnabled = scoreManage.saveSpinnerState
        if (scoreManage.gameEntryCount == 3 && scoreManage.hasSelectedMenu == false) {
            scoreManage.dropDownMenu(this, myText, spinnerID, list_for_rounds, gameRoundCount, btn)
        }
        scoreManage.saveTextFormyText = savedInstanceState.getString("saveTextFormyText", "")
        myText.text = scoreManage.saveTextFormyText
        listDice_text = savedInstanceState.getString("listDice_text", "")
        listDice.text = listDice_text
        scoreManage.pointSumList = savedInstanceState.getSerializable("pointSumList") as ArrayList<Int>
        scoreManage.selectedChoice = savedInstanceState.getString("selectedChoice", "")
        scoreManage.btnText = savedInstanceState.getString("btnText", "")
        btn.text = scoreManage.btnText
    }
}










