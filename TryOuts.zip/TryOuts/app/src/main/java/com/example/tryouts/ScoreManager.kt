package com.example.tryouts

import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView

// Det här är en klass som ska räkna ut poäng, hålla reda på och även låta användaren välja hur de vill
// att deras poäng ska summeras. Det vill säga är det en klass som ska ta hand om nästan allt som har med poäng att göra.
class ScoreManager {
    var gameEntryCount = 0
    var selectedChoice = " "
    var menuChoiceStorage: ArrayList<String> = ArrayList()
    var hasPickedSameMenu = false
    var hasSelectedMenu = true
    var saveTextFormyText: String = ""
    var btnText = ""
    var saveSpinnerState = false
    var pointSumList: ArrayList<Int> = ArrayList()
    lateinit var scoreText: TextView


    // Det här är en drop down meny där användaren kan trycka på och sedan välja olika alternativ
    fun dropDownMenu(mainActivity: MainActivity, myText: TextView, spinnerID: Spinner, list1: ArrayList<ArrayList<Int>>, gameRoundCount:Int, btn: Button){
        val choices = mutableListOf("-", "Low", "4", "5", "6", "7", "8", "9", "10", "11", "12")
        val arrAdapter = ArrayAdapter(mainActivity, android.R.layout.simple_spinner_dropdown_item, choices)
        // om vi har kört tre gånger så kommer jag aktivera meny:n
        if(gameEntryCount == 3){
            saveSpinnerState = true
            spinnerID.isEnabled = saveSpinnerState
        }
        spinnerID.adapter = arrAdapter
        spinnerID?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                scoreText = myText
                val temp = parent?.getItemAtPosition(position).toString()
                // bindesträck är ett default/standard värde så om vi har valt något annat så ska det behandlas annars ignorerar vi det
                if(!temp.equals("-")){
                    selectedChoice = temp
                    // Här kollar vi om det alternativet har redan valts
                    if(menuChoiceStorage.contains(selectedChoice.toString()) && !selectedChoice.equals("-")){
                        hasPickedSameMenu = true
                        saveTextFormyText = "       " + selectedChoice + " has already been used!\n       Pick another and press the button again."
                        myText.text = saveTextFormyText
                        spinnerID.setSelection(choices.indexOf("-"))
                    }
                    // om inte det har valts så kommer jag låta spelaren fortsätta spela samt kommer att uppdatera flaggorna
                    else if (choices.contains(selectedChoice) && !selectedChoice.equals("-") && !selectedChoice.equals(" ")){
                        sum_result(list1, gameRoundCount)//, myText)
                        saveTextFormyText = " "
                        hasSelectedMenu = true
                        hasPickedSameMenu = false
                        btnText = "Next\nRound"
                        btn.text = btnText
//                        menuChoiceStorage.add(selectedChoice.toString())

                        saveSpinnerState = false
                        spinnerID.isEnabled = saveSpinnerState

                        saveTextFormyText = "     Press button to continue! "
                        myText.text = saveTextFormyText

                }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
    }

    // Funktionen ska ta kolla på alternativet användaren valde och anropa en annan funktion som sedan ska
    // automatiskt räkna ut vad för poäng spelaren ska få på sin runda
    fun sum_result(list1: ArrayList<ArrayList<Int>>, gameRoundCount: Int){
        scoreText
        if(selectedChoice.equals("4")){
            pointSumList.add(findMaxSubset(list1[gameRoundCount], selectedChoice.toInt(), BooleanArray(list1[gameRoundCount].size)) * 4)
        } else if(selectedChoice.equals("5")){
            pointSumList.add(findMaxSubset(list1[gameRoundCount], selectedChoice.toInt(), BooleanArray(list1[gameRoundCount].size)) * 5)
        }else if(selectedChoice.equals("6")){
            pointSumList.add(findMaxSubset(list1[gameRoundCount], selectedChoice.toInt(), BooleanArray(list1[gameRoundCount].size)) * 6)
        }else if(selectedChoice.equals("7")){
            pointSumList.add(findMaxSubset(list1[gameRoundCount], selectedChoice.toInt(), BooleanArray(list1[gameRoundCount].size)) * 7)
        }else if(selectedChoice.equals("8")){
            pointSumList.add(findMaxSubset(list1[gameRoundCount], selectedChoice.toInt(), BooleanArray(list1[gameRoundCount].size)) * 8)
        }else if(selectedChoice.equals("9")){
            pointSumList.add(findMaxSubset(list1[gameRoundCount], selectedChoice.toInt(), BooleanArray(list1[gameRoundCount].size)) * 9)
        }else if(selectedChoice.equals("10")){
            pointSumList.add(findMaxSubset(list1[gameRoundCount], selectedChoice.toInt(), BooleanArray(list1[gameRoundCount].size)) * 10)
        }else if(selectedChoice.equals("11")){
            pointSumList.add(findMaxSubset(list1[gameRoundCount], selectedChoice.toInt(), BooleanArray(list1[gameRoundCount].size)) * 11)
        }else if(selectedChoice.equals("12")){
            pointSumList.add(findMaxSubset(list1[gameRoundCount], selectedChoice.toInt(), BooleanArray(list1[gameRoundCount].size)) * 12)
        }
        else if(selectedChoice.equals("Low")){
            var sum = 0
            for(elem in list1[gameRoundCount]){
                if(elem <= 3){
                    sum += elem
                }
            }
            pointSumList.add(sum)
        }
        else{

        }
    }


    // Den här funktionen itererar och börjar från varje element i listan för att kunna täcka alla möjliga fall
    // som skulle generera större antal gånger vi kan summera upp till vårt mål. Det gör den genom att kalla på
    // en hjälp funktion som körs rekursivt och kollar om vi kan få olika elements summor till att bli målet.

    private fun findMaxSubset(pointList: List<Int>, target: Int, visited: BooleanArray): Int {
        var maxCount = 0
        for (elem in pointList.indices) {
            if (!visited[elem]){
                // Skapar en kopia av lista visited array för varje rekursiv kallelse
                val visited2 = visited.copyOf()
                if (findMaxSubsetHelper(pointList, elem, target, visited2)) {
                    maxCount = maxOf(maxCount, 1 + findMaxSubset(pointList, target, visited2))
                }
            }
        }
        return maxCount
    }


    // Det här är en hjälp funktion och det är faktiskt här vi försöker hitta element som ger målsumman, dvs för varje obesökt index
    // om elementet på den indexen är mindre än målet så kommer vi subtrahera målet med den och fortsätta kolla om det finns
    // fler element tillsammans med de redan besökta ger subtraktionen 0 då returnerar vi sant annars falsk.
    // Om vi tillslut får noll då har vi hittat en delmängd vars summa ger målet och då backtracker vi och returnerar sant till
    // findMaxSubset och där ökar vi count med 1 och fortsätter upptäcka de oupptäckta fallen.
    private fun findMaxSubsetHelper(list: List<Int>, index: Int, target: Int, visited: BooleanArray): Boolean {
        if (target == 0) {
            return true
        }
        for (i in index until list.size) {
            if (!visited[i] && list[i] <= target) {
                visited[i] = true
                if (findMaxSubsetHelper(list, i + 1, target - list[i], visited)) {
                    return true
                }
                // Om vi inte hittar andra element som tillsammans ger summan målet då tar vi bort den som besökt
                visited[i] = false
            }
        }
        return false
    }


}