package com.example.tryouts
import android.widget.ImageView
import androidx.lifecycle.LiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import kotlin.random.Random


// En klass för att kunna hålla tillsåndet av variabler när aktivitet förstörs
// I denna klass har jag objekt eller variabler som är lite svåra att spara tillståndet av
// och det som den här klassen gör är att ta hand om nästan allt som har med att behålla bild status och uppdatera osv..
class ImageHandle(private val savedStateHandle: SavedStateHandle) : ViewModel() {

    // variabler som håller de olika tärningarna och savedStateHandle hjälper oss att behålla värden när processen dör
    val curImg1: LiveData<Int> = savedStateHandle.getLiveData<Int>("curImg1", R.drawable.dice0)
    val curImg2: LiveData<Int> = savedStateHandle.getLiveData<Int>("curImg2", R.drawable.dice0)
    val curImg3: LiveData<Int> = savedStateHandle.getLiveData<Int>("curImg3", R.drawable.dice0)
    val curImg4: LiveData<Int> = savedStateHandle.getLiveData<Int>("curImg4", R.drawable.dice0)
    val curImg5: LiveData<Int> = savedStateHandle.getLiveData<Int>("curImg5", R.drawable.dice0)
    val curImg6: LiveData<Int> = savedStateHandle.getLiveData<Int>("curImg6", R.drawable.dice0)


    // Gör btnXEnabled och curImgVisibilityX live data så att det blir smidigare att arbeta med i whenBtnClicked funktionen
    // eftersom jag vill kunna ge en parameter och kunna redigera den. Dessa variabler håller reda på en viewImage är synlig eller ej
    // och btn variablerna håller reda på om en button är aktiv/ inaktiv
    val curImgVisibility1: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("curImgVisibility1",true)
    val curImgVisibility2: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("curImgVisibility2",true)
    val curImgVisibility3: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("curImgVisibility3",true)
    val curImgVisibility4: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("curImgVisibility4",true)
    val curImgVisibility5: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("curImgVisibility5",true)
    val curImgVisibility6: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("curImgVisibility6",true)


    val btnEnabled1: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("btnEnabled1",true)
    val btnEnabled2: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("btnEnabled2",true)
    val btnEnabled3: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("btnEnabled3",true)
    val btnEnabled4: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("btnEnabled4",true)
    val btnEnabled5: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("btnEnabled5",true)
    val btnEnabled6: LiveData<Boolean> = savedStateHandle.getLiveData<Boolean>("btnEnabled6",true)



    // Det här är en funktion som ska kasta tärningarna slumpmässigt, egentligen har vi en lista som kallas "array" som
    // som innehåller drawables och för varje imageview ger vi någon slumässigt index i arrayen så de får slumpmässigt tärning drawable
    fun img_update(){
        val array = mutableListOf(R.drawable.dice1, R.drawable.dice2,  R.drawable.dice3, R.drawable.dice4, R.drawable.dice5, R.drawable.dice6)
        savedStateHandle["curImg1"] = array[Random.nextInt(0,6)]
        savedStateHandle["curImg2"] = array[Random.nextInt(0,6)]
        savedStateHandle["curImg3"] = array[Random.nextInt(0,6)]
        savedStateHandle["curImg4"] = array[Random.nextInt(0,6)]
        savedStateHandle["curImg5"] = array[Random.nextInt(0,6)]
        savedStateHandle["curImg6"] = array[Random.nextInt(0,6)]
    }

    // Det här är en funktion som hjälper oss att sätta ett värde för variabler i savedStateHandle.
    fun setValue(name: String, flag: Boolean){
        savedStateHandle[name] = flag
    }
    // Efter varje omgång så återställer jag alla imageviews till dice0 vilket är en tärning utan några punkter,
    // det ska liksom meddela att den här rundan är slut
    fun reset_images(){
        savedStateHandle["curImg1"] = R.drawable.dice0
        savedStateHandle["curImg2"] = R.drawable.dice0
        savedStateHandle["curImg3"] = R.drawable.dice0
        savedStateHandle["curImg4"] = R.drawable.dice0
        savedStateHandle["curImg5"] = R.drawable.dice0
        savedStateHandle["curImg6"] = R.drawable.dice0

    }

    // Den här funktionen jämför det som jag sparade som tag i MainActivity med de olika sidorna av tärningen och ersätt det
    // med siffror så det blir lättare att räkna ut saker i en lista.
    fun save_diceVal(mainActivity: MainActivity, imageView: ImageView, list1: ArrayList<ArrayList<Int>>, gameRoundCount: Int){
        if(imageView.tag == R.drawable.dice1){
            list1[gameRoundCount].add(1)
        }
        else if(imageView.tag == R.drawable.dice2){
            list1[gameRoundCount].add(2)
        }
        else if(imageView.tag == R.drawable.dice3){
            list1[gameRoundCount].add(3)
        }
        else if(imageView.tag == R.drawable.dice4){
            list1[gameRoundCount].add(4)
        }
        else if(imageView.tag == R.drawable.dice5){
            list1[gameRoundCount].add(5)
        }
        else if(imageView.tag == R.drawable.dice6){
            list1[gameRoundCount].add(6)
        }

    }

}
